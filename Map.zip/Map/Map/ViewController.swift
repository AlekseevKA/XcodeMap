//
//  ViewController.swift
//  Map
//
//  Created by Алексеев on 28.03.2022.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate{

    @IBOutlet weak var mapView: MKMapView!
    //перемещение для создания маршрута
    
    var itemMapFirst: MKMapItem!
    var itemMapSecond: MKMapItem!


    let manager: CLLocationManager = {
        let locationManager = CLLocationManager()
        
        locationManager.activityType = .fitness//точно определяет местоположение
        locationManager.desiredAccuracy = kCLLocationAccuracyBest//желаемая точность
        locationManager.distanceFilter = 1//фильтр дистанции
        locationManager.showsBackgroundLocationIndicator = true//показать индикатор локации заднего фона
        locationManager.pausesLocationUpdatesAutomatically = true//отображение обновления
        
        return locationManager
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        
        manager.delegate = self
        
       authorization()
       pinPosition()
        
        
    }
   func pinPosition(){
        //массивы с координатами
        let arrayLet = [63.74, 56.83]
        let arrayLon = [121.62, 60.64]
        
        for number in 0..<arrayLet.count{
            let point = MKPointAnnotation()
            point.title = "My point"
            point.coordinate = CLLocationCoordinate2D(latitude: arrayLet[number], longitude: arrayLon[number])
            mapView.addAnnotation(point)
        }

    }
    //функция которая выдает нам координаты
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        //отображение координат с помощью цикла
       for location in locations {
            print(location.coordinate.latitude)
            print(location.coordinate.longitude)
            itemMapFirst = MKMapItem(placemark: MKPlacemark(coordinate: location.coordinate))

        }
    }
    
    func authorization(){
        //проверка на разрешение использования местоположения always = всегда, inuse = когда приложение открыто
        if CLLocationManager.authorizationStatus() == .authorizedAlways || CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            mapView.showsUserLocation = true
        }else{
            manager.requestWhenInUseAuthorization()//запрос на использование местоположения пользователя
        }
    }
    
    func calculayeRoute(){
        
        let request = MKDirections.Request()
        
        request.source = itemMapFirst//начальная точка
        request.destination = itemMapSecond//конечная точка
        request.requestsAlternateRoutes = true
        request.transportType = .walking//автомобили дороги все
        
        let direction = MKDirections(request: request)
        direction.calculate {(response, error) in
            guard let directionResponse = response else {return}
            let route = directionResponse.routes[0]
            self.mapView.addOverlay(route.polyline, level: .aboveRoads)
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let render = MKPolygonRenderer(overlay: overlay)
        render.lineWidth = 5
        render.strokeColor = .red
        return render
    }
    
    
    


}

